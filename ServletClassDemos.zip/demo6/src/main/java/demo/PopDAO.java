package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class PopDAO {
	private String url = "jdbc:hsqldb:hsql://localhost/";

	public void change(String name) {
		// jdbc code to change op
		Connection con = null;
		Statement stmt = null;
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			con = DriverManager.getConnection(url, "sa", "");
			stmt = con.createStatement();
			String sql = "update popcount set count= count+1 where name = '" + name + "'";
			System.out.println("Current sql = " + sql);
			stmt.execute(sql);
		} catch (Exception e) {
			System.out.println("Exception " + e);
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public String read() {
		// jdbc code to change op
		Connection con = null;
		Statement stmt = null;
	String str ="";
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			con = DriverManager.getConnection(url, "sa", "");
			stmt = con.createStatement();
			String sql = "select * from popcount";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				str += rs.getString(1) + "   " + rs.getInt(2) + "\n";
			}
			System.out.println(str);
		} catch (Exception e) {
			System.out.println("Exception " + e);
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return str;
		
	}	
/*	public Map<String, Integer> read() {
		// jdbc code to change op
		Connection con = null;
		Statement stmt = null;
		Map<String, Integer> map = new HashMap<String, Integer>();
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			con = DriverManager.getConnection(url, "sa", "");
			stmt = con.createStatement();
			String sql = "select * from popcount";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				map.put(rs.getString(1), rs.getInt(2));
			}
			System.out.println(map);
		} catch (Exception e) {
			System.out.println("Exception " + e);
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return map;
		
	}
*/
}
