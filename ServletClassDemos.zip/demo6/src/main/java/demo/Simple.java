package demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/simple")
public class Simple extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Simple() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String name = request.getParameter("hero");
		System.out.println("in doGet " + name);
		PopDAO dao =new PopDAO();
		dao.change(name);
		
	/*	Map<String, Integer> map = dao.read();
		Set<String> keyset = map.keySet();
		Object[] arr = keyset.toArray();
		out.println("<table border='1' bgcolor='cyan'>");
		for(int i = 0;i<arr.length;i++) {
			out.println("<tr><td>" + arr[i] +"</td><td>" + map.get(arr[i]) +"</td></tr>");
		}
	
		out.println("</table>");*/
		out.println(dao.read());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
