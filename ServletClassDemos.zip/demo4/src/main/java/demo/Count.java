package demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Count
 */
@WebServlet("/count")
public class Count extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
      public Count() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int count = 0;

		HttpSession session = request.getSession();
		if (session.isNew())
		{
			System.out.println("New Session");
		}
		else
		{
			System.out.println("Existing Session");
			count = (int)session.getAttribute("cnt");
		}

		System.out.println("in doGet " + Thread.currentThread().getName());
		PrintWriter out  = response.getWriter();
		count+= Integer.parseInt(request.getParameter("nm"));
		
		session.setAttribute("cnt", count);
	
	
		out.println("<h1>Current Count = " + count + "</h1>");
		RequestDispatcher rd = this.getServletContext().getRequestDispatcher("/index.html");
		rd.include(request, response);
		out.println("<h1>From Count Servlet </h1>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
