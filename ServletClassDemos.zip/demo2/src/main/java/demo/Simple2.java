package demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Simple1
 */
@WebServlet("/simple2")
public class Simple2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		out.println("<h1>doGet of Simple2 invoked ...</h1>");
		String empno = request.getParameter("empno");
		String ename = request.getParameter("ename");
		String salary = request.getParameter("salary");
		
		out.println("<table bgcolor='cyan' border='1'>");
		out.println("<tr><td>EMPNO</td><td>ENAME</td><td>SALARY</td>");
		out.println("<tr><td>"  + empno+ "</td><td> " + ename +"</td><td>"+ salary+ "</td>");
		
		out.println("</table>");
		
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		out.println("<h1>doPost of Simple1 invoked ...</h1>");
	}

}
