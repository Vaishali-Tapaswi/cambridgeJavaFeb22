package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PollDAO {
	public double getAgreePercent() {
		Connection con = null;
		Statement stmt = null;
		double percent = 0;
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/", "sa", "");
			stmt = con.createStatement();
			String sql = "select * from poll";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
			int agree = rs.getInt(2);
			int disagree = rs.getInt(3);
			System.out.println("in getAgreePercent " + agree);
			int totalop = agree + disagree;
			percent = ((double) (100 * agree)) / totalop;
		} catch (Exception e) {
			System.out.println("Exception " + e);
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return percent;
	}

	public void modify(String op) {
		// jdbc code to change op
		System.out.println("Current op = " + op.toLowerCase());
		Connection con = null;
		Statement stmt = null;
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/", "sa", "");
			stmt = con.createStatement();
			String sql = "";
			// table has a single row
			if (op.equalsIgnoreCase("agree"))
				sql = "update poll set agree = agree+1";
			else
				sql = "update poll set disagree = disagree+1";
			stmt.execute(sql);
		} catch (Exception e) {
			System.out.println("Exception " + e);
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
