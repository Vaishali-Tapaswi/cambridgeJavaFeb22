package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class EmpDAO {
//

	public void insert(int empno, String ename, double salary) {
	Connection con = null;
	Statement stmt = null;
	try {
		Class.forName("org.hsqldb.jdbcDriver");
		con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/","SA","");
		stmt = con.createStatement();
		stmt.execute("INSERT INTO Emp VALUES ("+empno+", '" + ename +"', "+salary+")");
		System.out.println("Inserted");
	} catch (Exception e) {
			System.out.println(e);
	}finally {
		try {
			stmt.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}
}
